INSERT INTO price (currency, price, vehicle_id) VALUES ('USD', 100000, 1);
INSERT INTO price (currency, price, vehicle_id) VALUES ('SGD', 140000, 2);
INSERT INTO price (currency, price, vehicle_id) VALUES ('RM', 490000, 3);
INSERT INTO price (currency, price, vehicle_id) VALUES ('YEN', 15400000, 4);
INSERT INTO price (currency, price, vehicle_id) VALUES ('RUPEE', 8470000, 5);
